# build_your_homepage
本仓库是本人在CSDN博客的资源，详情查看博客文章[
【前端技术】从零开始在github创建个人主页或技术博客
](https://blog.csdn.net/m0_37201243/article/details/104851098)

【作者简介】[陈艺荣](http://yirongchen.com/)，男，目前在[华南理工大学电子与信息学院广东省人体数据科学工程技术研究中心](http://www.scut.edu.cn/ee/)攻读博士，担任IEEE Access、IEEE Photonics Journal的审稿人。两次获得美国大学生数学建模竞赛(MCM)一等奖，获得2017年全国大学生数学建模竞赛(广东赛区)一等奖、2018年广东省大学生电子设计竞赛一等奖等科技竞赛奖项，主持一项2017-2019年国家级大学生创新训练项目获得优秀结题，参与两项广东大学生科技创新培育专项资金、一项2018-2019年国家级大学生创新训练项目获得良好结题，发表SCI论文4篇，授权实用新型专利8项，受理发明专利13项。     
[我的主页](http://yirongchen.com/)      
[我的Github](https://github.com/scutcyr)     
[我的CSDN博客](https://blog.csdn.net/m0_37201243)      
[我的Linkedin](https://www.linkedin.com/in/chenyirong/)     

